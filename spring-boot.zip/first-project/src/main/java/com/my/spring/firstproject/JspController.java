package com.my.spring.firstproject;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class JspController {

    @GetMapping("/test-it/{param2}")
    public ModelAndView testJsp(@PathVariable(name = "param2") String param2) {
        ModelAndView result = new ModelAndView("test");
        result.addObject("param2", param2);
        return result;
    }
}
